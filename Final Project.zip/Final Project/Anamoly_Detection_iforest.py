# -*- coding: utf-8 -*-
"""
Created on Fri Jul 19 21:49:39 2024

@author: sumit
"""

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
from sklearn.model_selection import train_test_split # model split

# add the column labels
columns = (['duration'
,'protocol_type'
,'service'
,'flag'
,'src_bytes'
,'dst_bytes'
,'land'
,'wrong_fragment'
,'urgent'
,'hot'
,'num_failed_logins'
,'logged_in'
,'num_compromised'
,'root_shell'
,'su_attempted'
,'num_root'
,'num_file_creations'
,'num_shells'
,'num_access_files'
,'num_outbound_cmds'
,'is_host_login'
,'is_guest_login'
,'count'
,'srv_count'
,'serror_rate'
,'srv_serror_rate'
,'rerror_rate'
,'srv_rerror_rate'
,'same_srv_rate'
,'diff_srv_rate'
,'srv_diff_host_rate'
,'dst_host_count'
,'dst_host_srv_count'
,'dst_host_same_srv_rate'
,'dst_host_diff_srv_rate'
,'dst_host_same_src_port_rate'
,'dst_host_srv_diff_host_rate'
,'dst_host_serror_rate'
,'dst_host_srv_serror_rate'
,'dst_host_rerror_rate'
,'dst_host_srv_rerror_rate'
,'Label'])

df = pd.read_csv('kddcup.data',header=None,names=columns)

df.head() 

# drop columns with less than 3 unique values
# df.drop(['land', 'logged_in', 'root_shell','num_outbound_cmds', 'is_host_login', 'is_guest_login', 'level'], axis=1, inplace=True)
df.drop(['num_outbound_cmds'], axis=1, inplace=True) 

# compare the percentage of each label
# (df['Label'].value_counts() / df.shape[0]) * 100
(df['Label'].value_counts()) 

# take all the normal data and some of the abnormal data so the total data points are 1,000,000
df_normal = df[df['Label'] == 'normal.']
df_abnormal = df[df['Label'] != 'normal.']
for i in range(0,10):
    df_abnormal = df_abnormal.iloc[np.random.permutation(len(df_abnormal))]
    df_normal = df_normal.iloc[np.random.permutation(len(df_normal))]
df_abnormal = df_abnormal.sample(1000000 - df_normal.shape[0]) 

df_normal.shape, df_abnormal.shape

df_normal
 
df_abnormal

# combine the normal and abnormal data
df = pd.concat([df_normal, df_abnormal])
df 

# compare the percentage of each label
# (df['Label'].value_counts() / df.shape[0]) * 100
(df['Label'].value_counts()) 

for f in range(0,10):
    df = df.iloc[np.random.permutation(len(df))]

# split X and y data
x = df.drop('Label', axis = 1)
y = df['Label'] 

from sklearn.compose import ColumnTransformer
from sklearn.ensemble import IsolationForest
from sklearn.neighbors import LocalOutlierFactor
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import (
    OneHotEncoder,
    OrdinalEncoder,
    RobustScaler,
    StandardScaler,
)
categorical_columns = ["protocol_type", "service", "flag"]

ordinal_encoder = OrdinalEncoder(
    handle_unknown="use_encoded_value", unknown_value=-1
)
preprocessor = ColumnTransformer(
    transformers=[
        ("categorical", ordinal_encoder, categorical_columns),
    ],
    remainder="passthrough",
)
x = preprocessor.fit_transform(x)
y = np.where(y == 'normal.',1,0) # anomaly = 0, normal = 1

x_train, x_test, y_train, y_test = train_test_split(x ,y , test_size = 0.2, random_state = 42)
x_train = df_normal.drop('Label', axis = 1) # remake x_train with only normal data
x_train = preprocessor.fit_transform(x_train)  

iforest = IsolationForest(n_estimators=100, bootstrap=True, random_state=42)
iforest.fit(x_train)
y_pred1 = iforest.predict(x_test)
y_pred1 = np.where(y_pred1 == 1, 1, 0) # normal = 1, anomaly = 0
y_pred2 = iforest.decision_function(x_test) 
y_pred1

y_pred2 

y_test

from sklearn.metrics import classification_report
print("Printing the classification report with fixed parameters...")
print(classification_report(y_test, y_pred1)) 

import math
import matplotlib.pyplot as plt
from sklearn.metrics import RocCurveDisplay, roc_auc_score, roc_curve, auc

fpr, tpr, thresholds = roc_curve(y_test, y_pred2)
roc_auc = auc(fpr, tpr)
curve = RocCurveDisplay(fpr=fpr, tpr=tpr,roc_auc=roc_auc)
curve.plot()
plt.title("IForest for OCC on KDD cup 1999")
plt.show()

from sklearn.metrics import roc_auc_score
auc1 = roc_auc_score(y_test, y_pred1)
auc2 = roc_auc_score(y_test, y_pred2)
print("AUC score (discrete prediction): ", auc1 * 100)
print("AUC score (continuous prediction):", auc2 * 100) 

plt.figure(figsize = (15, 10))

plt.hist(y_pred2, bins=100)

plt.xlabel('Avr anomaly score', fontsize=14)

plt.ylabel('Number of Data Points', fontsize=14)

plt.show()















